from alpha import *

bot = Bot('!', Intents.all())
data = Data()
@bot.app_command(name='ping', description='Replies with pong!')
async def ping(interaction:Interaction):
  await interaction.response.send_message('Pong')

bot.run('MTE4ODM5ODExODc5OTE2NzU2OQ.G0GUis.ck3rMJuUhcaLxwWddGvqq2Tm7jPRamYafdqkQA', True)
