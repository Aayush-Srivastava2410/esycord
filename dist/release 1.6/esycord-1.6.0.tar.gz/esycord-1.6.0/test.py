from src.esycord import *


bot = Bot("!", discord.Intents.all())

@bot.app_command(name="ping", description="Replies with Pong!")
async def ping(interaction:discord.Interaction):
    await interaction.response.send_message("Pong!")

@bot.command()
async def hi(ctx):
    await ctx.send("Hello!")

bot.run()