from future.esycord import Bot, Voice, Intents, Interaction


bot = Bot('!', Intents.all())
voice = Voice(bot)


@bot.app_command(name='ping', description='Replies with pong!')
async def ping(interaction:Interaction):
  await interaction.response.send_message('Pong!')
  await voice.join(interaction.user.voice.channel)

@bot.command(pass_context=True)
async def join(ctx):
  if ctx.voice:
    await voice.join(ctx.voice.channel)

bot.run("MTE4ODM5ODExODc5OTE2NzU2OQ.G0GUis.ck3rMJuUhcaLxwWddGvqq2Tm7jPRamYafdqkQA")

