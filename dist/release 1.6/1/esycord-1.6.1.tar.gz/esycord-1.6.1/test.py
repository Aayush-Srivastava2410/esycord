from src.esycord import *

bot = Bot('!', Intents.all()) #This statement may vary according to your need.

@bot.command
async def ping(ctx):
    await ctx.send('Pong!')

bot.run()