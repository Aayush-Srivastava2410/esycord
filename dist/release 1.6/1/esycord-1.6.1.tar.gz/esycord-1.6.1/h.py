from src.esycord import *

Bot("!").run()