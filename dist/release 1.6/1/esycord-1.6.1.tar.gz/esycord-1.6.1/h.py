import argparse 
import sys

bot = r"""
from esycord import *

token = "YOUR_TOKEN_HERE"
intents = Intents.default()
intents.message_content = True
bot = Bot('!',intents)

@bot.command()
async def ping(ctx):
  await ctx.send("Pong!") # command : !ping

bot.run()
"""



parser = argparse.ArgumentParser(
    description='Makes an example of ')
parser.add_argument(
    '-example',required=True,choices=['bot', 'webhook', 'data'],type=str,
    help='Bot Example')
parser.add_argument(
    '--log', default=sys.stdout, type=argparse.FileType('w'),
    help='File to log into. Prints to console if empty')
args = parser.parse_args()
if args.example=='bot':args.log.write(bot)
args.log.close()


