import src.esycord as esycord

bot=esycord.Bot("!")

bot.run()